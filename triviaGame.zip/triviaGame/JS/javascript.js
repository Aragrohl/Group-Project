

/*
Author Name: 14 Eyes - Mort Hedges
Project Name: In for a penny in for a pound
Date: 10/02/2020
Module: Computing project
Version: V1
*/

var correctans = 0;
var level = 0;

var questions = [

	["What is the command to copy","CTRL C","Shift C","CTRL A","CTRL V", 1],
	["What was Twitters original Name","Bluebird","Twitter","twttr","Tweeter", 3],
	["What is meteorology the study of?","Meteors","The Weather","Tides","The Moon", 2],
	["What is the symbol for potassium","Pk","P","Pt","K", 4],
	["How many molecules of oxygen does ozone have","3","1","0","5", 1],
	["What other name does “corn” go by?","Starch","Maize","Grain","Wheat", 2],
	["About how many taste buds does the average human tongue have?","10,000","100,000","1 Million","2,000", 1],
	["How many times does the heart beat per day","5,000","250,000","100,000","10,00", 3],
	["Which bone are babies born without?","Parts of the skull","Elbows","One set of ribs","Knee caps", 4],
	["Which American state is the largest (by area)?","Michagin","Alaska","Ohio","Washington", 2]
]

function randomNum() {
    var num = 0;
    num = Math.floor((Math.random() * 10) + 1);
    return num;   
}

function question() {
	
	document.getElementById("question").innerHTML = questions[level][0];
	
	document.getElementById("answer1").innerHTML = questions[level][1];
	document.getElementById("answer2").innerHTML = questions[level][2];
	document.getElementById("answer3").innerHTML = questions[level][3];
	document.getElementById("answer4").innerHTML = questions[level][4];
	
	correctans = questions[level][5];
	
	document.getElementById("Lvl1").style.backgroundColor = "white";
	document.getElementById("Lvl2").style.backgroundColor = "white";
	document.getElementById("Lvl3").style.backgroundColor = "white";
	document.getElementById("Lvl4").style.backgroundColor = "white";
	document.getElementById("Lvl5").style.backgroundColor = "white";
	document.getElementById("Lvl6").style.backgroundColor = "white";
	document.getElementById("Lvl7").style.backgroundColor = "white";
	document.getElementById("Lvl8").style.backgroundColor = "white";
	document.getElementById("Lvl9").style.backgroundColor = "white";
	document.getElementById("Lvl10").style.backgroundColor = "white";
	
	
	
	if (level == 0)
	{
		document.getElementById("Lvl1").style.backgroundColor = "rgb(0, 153, 153)";
	}
	
	if (level == 1)
	{
		document.getElementById("Lvl2").style.backgroundColor = "rgb(0, 153, 153)";
	}	
	
	if (level == 2)
	{
		document.getElementById("Lvl3").style.backgroundColor = "rgb(0, 153, 153)";
	}	
	
	if (level == 3)
	{
		document.getElementById("Lvl4").style.backgroundColor = "rgb(0, 153, 153)";
	}	
	
	if (level == 4)
	{
		document.getElementById("Lvl5").style.backgroundColor = "rgb(0, 153, 153)";
	}
	
	if (level == 5)
	{
		document.getElementById("Lvl6").style.backgroundColor = "rgb(0, 153, 153)";
	}
	
	if (level == 6)
	{
		document.getElementById("Lvl7").style.backgroundColor = "rgb(0, 153, 153)";
	}
	
	if (level == 7)
	{
		document.getElementById("Lvl8").style.backgroundColor = "rgb(0, 153, 153)";
	}
	
	if (level == 8)
	{
		document.getElementById("Lvl9").style.backgroundColor = "rgb(0, 153, 153)";
	}
	
	if (level == 9)
	{
		document.getElementById("Lvl10").style.backgroundColor = "rgb(0, 153, 153)";
	}
}

function A() {
	if (correctans == 1)
	{
		if (level < 10)
		{
			level = level + 1;
			question()
		}
	}
	else {
		document.getElementById("question").innerHTML = "You Lose!";
		level = 11;
	}
}

function B() {
	if (correctans == 2)
	{
		if (level < 10)
		{
			level = level + 1;
			question()
		}	
	}
	else {
		document.getElementById("question").innerHTML = "You Lose!";
		level = 11;
	}
}

function C() {
	if (correctans == 3)
	{
		if (level < 10)
		{
			level = level + 1;
			question()
		}
	}
	else {
		document.getElementById("question").innerHTML = "You Lose!";
		level = 11;
	}
}

function D() {
	if (correctans == 4)
	{
		if (level < 10)
		{
			level = level + 1;
			question()
		}
	}
	else {
		document.getElementById("question").innerHTML = "You Lose!";
		level = 11;
	}
}


/*
"What is 2 squared?", - Question
true, - Has it been asked?
4, - Correct answer
2, - Answer
9, - Answer
7  - Answer
*/ 
