/*
Author Name: 14 Eyes - Mort Hedges
Project Name: In for a penny in for a pound
Date: 10/02/2020
Module: Computing project
Version: V1
*/

var correctans = 0;
var level = 0;
var aLock = false;
var bLock = false;
var cLock = false;
var dLock = false;

var fiftyUsed = false;
var hintUsed = false;

var questions = [

	["What is the command to copy","CTRL C","Shift C","CTRL A","CTRL V", 1,"It Involves C"],
	["What was Twitters original Name","Bluebird","Twitter","twttr","Tweeter", 3,"Less is more"],
	["What is meteorology the study of?","Meteors","The Weather","Tides","The Moon", 2,"Doesnt involve the moon"],
	["What is the symbol for potassium","Pk","P","Pt","K", 4,"Ok then"],
	["How many molecules of oxygen does ozone have","3","1","0","5", 1,"To be honest just good luck with this one"],
	["What other name does “corn” go by?","Starch","Maize","Grain","Wheat", 2,"Spooky"],
	["About how many taste buds does the average human tongue have?","10,000","100,000","1 Million","2,000", 1,"Multiple of 10,000"],
	["How many times does the heart beat per day","5,000","250,000","100,000","10,000", 3,"Starts with 1"],
	["Which bone are babies born without?","Parts of the skull","Elbows","One set of ribs","Knee caps", 4,"Not the skull"],
	["Which American state is the largest (by area)?","Michagin","Alaska","Ohio","Washington", 2,"No"]
];


function question() {
	
	document.getElementById("question").innerHTML = questions[level][0];
	
	document.getElementById("answer1").innerHTML = questions[level][1];
	document.getElementById("answer2").innerHTML = questions[level][2];
	document.getElementById("answer3").innerHTML = questions[level][3];
	document.getElementById("answer4").innerHTML = questions[level][4];
	
	correctans = questions[level][5];
	
	document.getElementById("Lvl1").style.backgroundColor = "white";
	document.getElementById("Lvl2").style.backgroundColor = "white";
	document.getElementById("Lvl3").style.backgroundColor = "white";
	document.getElementById("Lvl4").style.backgroundColor = "white";
	document.getElementById("Lvl5").style.backgroundColor = "white";
	document.getElementById("Lvl6").style.backgroundColor = "white";
	document.getElementById("Lvl7").style.backgroundColor = "white";
	document.getElementById("Lvl8").style.backgroundColor = "white";
	document.getElementById("Lvl9").style.backgroundColor = "white";
	document.getElementById("Lvl10").style.backgroundColor = "white";
	
	document.getElementById("answer1").style.backgroundColor = "rgb(255,255,255)";
	document.getElementById("answer2").style.backgroundColor = "rgb(255,255,255)";
	document.getElementById("answer3").style.backgroundColor = "rgb(255,255,255)";
	document.getElementById("answer4").style.backgroundColor = "rgb(255,255,255)";
	
	aLock = false;
	bLock = false;
	cLock = false;
	dLock = false;
	
	document.getElementById("subquestion").innerHTML = "";
	
	
	
	if (level == 0)
	{
		document.getElementById("Lvl1").style.backgroundColor = "rgb(150, 150, 150)";
	}
	
	if (level == 1)
	{
		document.getElementById("Lvl2").style.backgroundColor = "rgb(0, 139, 139)";
	}	
	
	if (level == 2)
	{
		document.getElementById("Lvl3").style.backgroundColor = "rgb(0, 139, 139)";
	}	
	
	if (level == 3)
	{
		document.getElementById("Lvl4").style.backgroundColor = "rgb(0, 139, 139)";
	}	
	
	if (level == 4)
	{
		document.getElementById("Lvl5").style.backgroundColor = "rgb(0, 139, 139)";
	}
	
	if (level == 5)
	{
		document.getElementById("Lvl6").style.backgroundColor = "rgb(0, 139, 139)";
	}
	
	if (level == 6)
	{
		document.getElementById("Lvl7").style.backgroundColor = "rgb(0, 139, 139)";
	}
	
	if (level == 7)
	{
		document.getElementById("Lvl8").style.backgroundColor = "rgb(0, 139, 139)";
	}
	
	if (level == 8)
	{
		document.getElementById("Lvl9").style.backgroundColor = "rgb(0, 139, 139)";
	}
	
	if (level == 9)
	{
		document.getElementById("Lvl10").style.backgroundColor = "rgb(0, 139, 139)";
	}
}

function A() {
	if (!aLock) 
		{
		if (correctans == 1)
		{
			if (level == 9)
			{
				document.getElementById("question").innerHTML = "You Win!";
			}			
			if (level < 9)
			{
				level = level + 1;
				question()
			} 
		}
		else {
			document.getElementById("question").innerHTML = "You Lose!";
			aLock = true;
		}
	}
}

function B() {
	if (!bLock)
	{
		if (correctans == 2)
		{
			if (level == 9)
			{
				document.getElementById("question").innerHTML = "You Win!";
			}
			if (level < 9)
			{
				level = level + 1;
				question()
			} 
		}else {
			document.getElementById("question").innerHTML = "You Lose!";
			bLock = true;
		}
	}
}
function C() {
	if (!cLock)
	{
		if (correctans == 3)
		{
			if (level == 9)
			{
				document.getElementById("question").innerHTML = "You Win!";
			}
			if (level < 9)
			{
				level = level + 1;
				question()
			} 
		}
		else {
			document.getElementById("question").innerHTML = "You Lose!";
			cLock = true;
		}
	}
}

function D() {
	if (!dLock)
	{
		if (correctans == 4)
		{
			if (level == 9)
			{
				document.getElementById("question").innerHTML = "You Win!";
			}
			if (level < 9)
			{
				level = level + 1;
				question()
			}
		}
		else {
			document.getElementById("question").innerHTML = "You Lose!";
			dLock = true;
		}
	}
}


function fifty()
{
	if (!fiftyUsed)
	{
		fiftyUsed = true;
		if (questions[level][5] == 1)
		{
			dLock = true;
			cLock = true;
			document.getElementById("answer3").style.backgroundColor = "rgb(220,20,60)";
			document.getElementById("answer4").style.backgroundColor = "rgb(220,20,60)";
		}
		
		if (questions[level][5] == 2)
		{
			aLock = true;
			dLock = true;
			document.getElementById("answer1").style.backgroundColor = "rgb(220,20,60)";
			document.getElementById("answer4").style.backgroundColor = "rgb(220,20,60)";
		}
		
		if (questions[level][5] == 3)
		{
			aLock = true;
			bLock = true;
			document.getElementById("answer1").style.backgroundColor = "rgb(220,20,60)";
			document.getElementById("answer2").style.backgroundColor = "rgb(220,20,60)";
		}
		
		if (questions[level][5] == 4)
		{
			bLock = true;
			cLock = true;
			document.getElementById("answer2").style.backgroundColor = "rgb(220,20,60)";
			document.getElementById("answer3").style.backgroundColor = "rgb(220,20,60)";
		}
	}
}

function hints()
{
	if (!hintUsed)
	{
		hintUsed = true;
		document.getElementById("subquestion").innerHTML = questions[level][6];
	}
}

